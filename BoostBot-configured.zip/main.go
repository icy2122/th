// language: Go, file: main.go, target: Windows/Linux, Go 1.21+
// entry: main() — loads config, starts bot + automation loop
package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/bwmarrin/discordgo"
)

// ── Config ────────────────────────────────────────────────────────────────────

type Config struct {
	BotToken      string   `json:"botToken"`
	GuildID       string   `json:"guildID"`
	LogsChannelID string   `json:"logsChannelID"`
	Prefix        string   `json:"prefix"`
	Owners        []string `json:"owners"`
	EmbedColor    int      `json:"embedColor"`
	Proxyless     bool     `json:"proxyless"`
	Timeout       int      `json:"timeout"`
	TokenFiles    struct {
		OneMonth   string `json:"1month"`
		ThreeMonth string `json:"3month"`
	} `json:"tokenFiles"`
}

var cfg Config

func loadConfig() error {
	data, err := os.ReadFile("config.json")
	if err != nil {
		return fmt.Errorf("config.json not found: %w", err)
	}
	return json.Unmarshal(data, &cfg)
}

// ── Token Store ───────────────────────────────────────────────────────────────

type TokenStore struct {
	mu         sync.Mutex
	oneMonth   []string
	threeMonth []string
	used       []string
	failed     []string
}

var store TokenStore

func loadTokens(path string) []string {
	f, err := os.Open(path)
	if err != nil {
		return nil
	}
	defer f.Close()
	var out []string
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		// support token:email:pass or bare token
		parts := strings.SplitN(line, ":", 2)
		out = append(out, parts[0])
	}
	return out
}

func (s *TokenStore) Load() {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.oneMonth = loadTokens(cfg.TokenFiles.OneMonth)
	s.threeMonth = loadTokens(cfg.TokenFiles.ThreeMonth)
	fmt.Printf("[+] Loaded %d 1-month tokens, %d 3-month tokens\n",
		len(s.oneMonth), len(s.threeMonth))
}

func (s *TokenStore) Pop(monthType string) (string, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	var list *[]string
	if monthType == "3m" {
		list = &s.threeMonth
	} else {
		list = &s.oneMonth
	}
	if len(*list) == 0 {
		return "", false
	}
	tok := (*list)[0]
	*list = (*list)[1:]
	return tok, true
}

func (s *TokenStore) Count() (int, int) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return len(s.oneMonth), len(s.threeMonth)
}

func (s *TokenStore) AppendFailed(tok string) {
	s.mu.Lock()
	s.failed = append(s.failed, tok)
	s.mu.Unlock()
	_ = appendLine("Data/failed.txt", tok)
}

func (s *TokenStore) AppendUsed(tok string) {
	s.mu.Lock()
	s.used = append(s.used, tok)
	s.mu.Unlock()
	_ = appendLine("Data/used.txt", tok)
}

func appendLine(path, line string) error {
	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = f.WriteString(line + "\n")
	return err
}

// ── Discord API client (user tokens) ──────────────────────────────────────────

var xSuperProps = "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzExNi4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTE2LjAuMC4wIiwib3NfdmVyc2lvbiI6IjEwIiwicmVmZXJyZXIiOiIiLCJyZWZlcnJpbmdfZG9tYWluIjoiIiwicmVmZXJyZXJfY3VycmVudCI6IiIsInJlZmVycmluZ19kb21haW5fY3VycmVudCI6IiIsInJlbGVhc2VfY2hhbm5lbCI6InN0YWJsZSIsImNsaWVudF9idWlsZF9udW1iZXIiOjIyMzk5NiwiY2xpZW50X2V2ZW50X3NvdXJjZSI6bnVsbH0="

func discordHeaders(token string) http.Header {
	h := http.Header{}
	h.Set("Authorization", token)
	h.Set("Content-Type", "application/json")
	h.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36")
	h.Set("X-Discord-Locale", "en-US")
	h.Set("X-Super-Properties", xSuperProps)
	return h
}

func httpClient() *http.Client {
	t := cfg.Timeout
	if t == 0 {
		t = 30
	}
	return &http.Client{Timeout: time.Duration(t) * time.Second}
}

type SlotResponse struct {
	ID           string  `json:"id"`
	GuildID      *string `json:"guild_id"`
	CooldownEnds *string `json:"cooldown_ends_at"`
}

// getAvailableSlots returns slot IDs that are unused and off cooldown
func getAvailableSlots(token string) ([]string, error) {
	client := httpClient()
	req, _ := http.NewRequest("GET",
		"https://discord.com/api/v9/users/@me/guilds/premium/subscription-slots", nil)
	req.Header = discordHeaders(token)

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)

	if resp.StatusCode == 401 {
		return nil, fmt.Errorf("invalid token")
	}
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("slots fetch: status %d — %s", resp.StatusCode, string(body))
	}

	var slots []SlotResponse
	if err := json.Unmarshal(body, &slots); err != nil {
		return nil, fmt.Errorf("parse slots: %w", err)
	}

	var available []string
	for _, s := range slots {
		if s.GuildID == nil && s.CooldownEnds == nil {
			available = append(available, s.ID)
		}
	}
	return available, nil
}

// joinServer joins via invite code and returns the guild ID
func joinServer(token, inviteCode string) (string, error) {
	payload, _ := json.Marshal(map[string]string{})
	client := httpClient()
	url := fmt.Sprintf("https://discord.com/api/v9/invites/%s", inviteCode)
	req, _ := http.NewRequest("POST", url, bytes.NewBuffer(payload))
	req.Header = discordHeaders(token)

	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)

	if resp.StatusCode != 200 {
		return "", fmt.Errorf("join failed: status %d", resp.StatusCode)
	}

	var result struct {
		Guild struct {
			ID string `json:"id"`
		} `json:"guild"`
	}
	json.Unmarshal(body, &result)
	return result.Guild.ID, nil
}

// applyBoost applies slot IDs to a guild
func applyBoost(token, guildID string, slotIDs []string) error {
	payload, _ := json.Marshal(map[string]interface{}{
		"user_premium_guild_subscription_slot_ids": slotIDs,
	})
	client := httpClient()
	url := fmt.Sprintf("https://discord.com/api/v9/guilds/%s/premium/subscriptions", guildID)
	req, _ := http.NewRequest("PUT", url, bytes.NewBuffer(payload))
	req.Header = discordHeaders(token)

	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)

	if resp.StatusCode == 201 || resp.StatusCode == 200 {
		return nil
	}
	return fmt.Errorf("boost apply: status %d — %s", resp.StatusCode, string(body))
}

// ── Boost worker ──────────────────────────────────────────────────────────────

type BoostResult struct {
	Token   string
	Slots   int
	Success bool
	Err     string
}

// boostOne grabs one token, joins the guild if needed, and applies available slots
func boostOne(token, guildID, inviteCode, monthType string) BoostResult {
	res := BoostResult{Token: token[:min(len(token), 20)] + "..."}

	// join via invite if provided
	if inviteCode != "" {
		if _, err := joinServer(token, inviteCode); err != nil {
			store.AppendFailed(token)
			res.Err = "join: " + err.Error()
			return res
		}
		time.Sleep(500 * time.Millisecond)
	}

	slots, err := getAvailableSlots(token)
	if err != nil {
		store.AppendFailed(token)
		res.Err = "slots: " + err.Error()
		return res
	}
	if len(slots) == 0 {
		store.AppendFailed(token)
		res.Err = "no available slots"
		return res
	}

	if err := applyBoost(token, guildID, slots); err != nil {
		store.AppendFailed(token)
		res.Err = "boost: " + err.Error()
		return res
	}

	store.AppendUsed(token)
	res.Success = true
	res.Slots = len(slots)
	return res
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

// ── Bot ───────────────────────────────────────────────────────────────────────

var bot *discordgo.Session

func isOwner(userID string) bool {
	for _, o := range cfg.Owners {
		if o == userID {
			return true
		}
	}
	return false
}

func sendEmbed(s *discordgo.Session, channelID, title, desc string, color int) {
	s.ChannelMessageSendEmbed(channelID, &discordgo.MessageEmbed{
		Title:       title,
		Description: desc,
		Color:       color,
		Timestamp:   time.Now().Format(time.RFC3339),
	})
}

func logToChannel(title, desc string, success bool) {
	if cfg.LogsChannelID == "" || bot == nil {
		return
	}
	color := 0x00FF00
	if !success {
		color = 0xFF0000
	}
	sendEmbed(bot, cfg.LogsChannelID, title, desc, color)
}

func onMessage(s *discordgo.Session, m *discordgo.MessageCreate) {
	fmt.Printf("[MSG] from=%s content=%q\n", m.Author.Username, m.Content)
	if m.Author.Bot || m.Author.ID == s.State.User.ID {
		return
	}
	if !strings.HasPrefix(m.Content, cfg.Prefix) {
		return
	}
	if len(cfg.Owners) > 0 && !isOwner(m.Author.ID) {
		sendEmbed(s, m.ChannelID, "❌ Unauthorized", "You don't have permission.", 0xFF0000)
		return
	}

	parts := strings.Fields(m.Content[len(cfg.Prefix):])
	if len(parts) == 0 {
		return
	}

	cmd := strings.ToLower(parts[0])

	switch cmd {

	// !boost <amount> [1m|3m] [invite]
	case "boost":
		if len(parts) < 2 {
			sendEmbed(s, m.ChannelID, "Usage", cfg.Prefix+"boost <amount> [1m|3m] [invite]", cfg.EmbedColor)
			return
		}
		amount, err := strconv.Atoi(parts[1])
		if err != nil || amount < 1 {
			sendEmbed(s, m.ChannelID, "❌ Error", "Amount must be a positive number.", 0xFF0000)
			return
		}
		monthType := "1m"
		if len(parts) >= 3 && parts[2] == "3m" {
			monthType = "3m"
		}
		invite := ""
		if len(parts) >= 4 {
			invite = parts[3]
		}

		sendEmbed(s, m.ChannelID, "🚀 Boosting", fmt.Sprintf("Starting %d boosts (%s)...", amount, monthType), cfg.EmbedColor)

		go func() {
			success, fail := 0, 0
			for i := 0; i < amount; i++ {
				tok, ok := store.Pop(monthType)
				if !ok {
					sendEmbed(s, m.ChannelID, "⚠️ Out of tokens", fmt.Sprintf("Ran out after %d boosts", i), 0xFF8800)
					break
				}
				res := boostOne(tok, cfg.GuildID, invite, monthType)
				if res.Success {
					success++
					logToChannel("✅ Boost Success",
						fmt.Sprintf("Token: `%s`\nSlots used: %d", res.Token, res.Slots), true)
				} else {
					fail++
					logToChannel("❌ Boost Failed",
						fmt.Sprintf("Token: `%s`\nReason: %s", res.Token, res.Err), false)
				}
				time.Sleep(300 * time.Millisecond)
			}
			sendEmbed(s, m.ChannelID, "✅ Done",
				fmt.Sprintf("**Success:** %d\n**Failed:** %d", success, fail), 0x00FF00)
		}()

	// !stock
	case "stock":
		one, three := store.Count()
		sendEmbed(s, m.ChannelID, "📦 Token Stock",
			fmt.Sprintf("**1-Month:** %d tokens\n**3-Month:** %d tokens", one, three),
			cfg.EmbedColor)

	// !reload — reload tokens from disk
	case "reload":
		store.Load()
		one, three := store.Count()
		sendEmbed(s, m.ChannelID, "🔄 Reloaded",
			fmt.Sprintf("**1-Month:** %d\n**3-Month:** %d", one, three), cfg.EmbedColor)

	// !help
	case "help":
		help := fmt.Sprintf(
			"`%sboost <amount> [1m|3m] [invite]` — boost the configured guild\n"+
				"`%sstock` — check available token count\n"+
				"`%sreload` — reload tokens from disk",
			cfg.Prefix, cfg.Prefix, cfg.Prefix,
		)
		sendEmbed(s, m.ChannelID, "📋 Commands", help, cfg.EmbedColor)
	}
}

// ── Main ──────────────────────────────────────────────────────────────────────

func main() {
	if err := loadConfig(); err != nil {
		fmt.Println("[-] Failed to load config:", err)
		os.Exit(1)
	}

	if cfg.Prefix == "" {
		cfg.Prefix = "!"
	}
	if cfg.EmbedColor == 0 {
		cfg.EmbedColor = 0x800080
	}

	store.Load()

	var err error
	bot, err = discordgo.New("Bot " + cfg.BotToken)
	if err != nil {
		fmt.Println("[-] Failed to create bot session:", err)
		os.Exit(1)
	}

	bot.AddHandler(onMessage)
	bot.Identify.Intents = discordgo.IntentsAll

	if err := bot.Open(); err != nil {
		fmt.Println("[-] Failed to connect:", err)
		os.Exit(1)
	}

	fmt.Printf("[+] Bot online as %s#%s\n", bot.State.User.Username, bot.State.User.Discriminator)
	fmt.Printf("[+] Prefix: %s | Guild: %s\n", cfg.Prefix, cfg.GuildID)

	sc := make(chan os.Signal, 1)
	signal.Notify(sc, syscall.SIGINT, syscall.SIGTERM)
	<-sc

	fmt.Println("\n[*] Shutting down...")
	bot.Close()
}

