module BoostBot

go 1.21.0

require (
	github.com/bwmarrin/discordgo v0.27.1
	github.com/gorilla/websocket v1.5.0
	github.com/skip2/go-qrcode v0.0.0-20200617195104-da1b6568686e
)

require (
	golang.org/x/crypto v0.0.0-20210421170649-83a5a9bb288b // indirect
	golang.org/x/sys v0.0.0-20201119102817-f84b799fce68 // indirect
)
